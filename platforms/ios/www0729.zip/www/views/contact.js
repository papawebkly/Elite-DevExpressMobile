Elite['contact'] = function(params) {

    var viewModel = {
        full_name: 'Bristol Global',
        phone_usa: '1 888 371 4297',
        phone_global: '+ 1 602 952 0355',
        phone_emea: '+ 44 179 952 9000',
        phone_apac: '+ 65 6653 3421',
        phone_fax: '+1.602.952.1557',
        address_line_1: '2001 N. 3rd Street',
        address_line_2: 'Suite 200',
        city_state_zip: 'Phoenix, AZ 85004',
        city: 'Phoenix',
        state_code: 'AZ',
        zip_code: '85004'
    };

    return viewModel;
}