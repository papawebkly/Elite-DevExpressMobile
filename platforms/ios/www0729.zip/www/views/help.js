Elite.help = function(params) {
    var viewModel = {
	};
    return viewModel;
};